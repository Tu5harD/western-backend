const isPresent = {
    false: {
        label: 'Absent'
    },
    true: {
        label: 'Present'
    }
}

module.exports = isPresent 