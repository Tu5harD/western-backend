const role = {
  AD: {
    label: "Admin",
  },
  EX: {
    label: "Executive",
  },
  RT: {
    label: "Retailer",
  },
};

module.exports = role;
